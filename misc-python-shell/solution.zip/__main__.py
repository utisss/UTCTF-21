with open ( '/flag.txt') as f:
	print (f.read( ) )
#with opedaf awea 6 \ #$n( '3 /f#a #s#d3 f.txt') as f:
   #     p#r#i#nt#(#f3.#read())
#with open('/flag.txt') as f:
#        print(f.read())


